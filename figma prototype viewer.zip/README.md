
  # figma prototype viewer

  This is a code bundle for figma prototype viewer. The original project is available at https://www.figma.com/design/jyM7UH1LdsddvjjqR0NwpV/figma-prototype-viewer.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  